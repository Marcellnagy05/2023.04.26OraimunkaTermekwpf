﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;

namespace WpfApp6
{

    public partial class MainWindow : Window
    {
        const string connectionString="datasource=127.0.0.1;port=3306;database=hardver;password=;username=root";
        List<termek> Termekek = new List<termek>();
        MySqlConnection sqlConnection;
        public MainWindow()
        {
            InitializeComponent();
            Opendatabase();
            OpenCategories();
            OpenProviders();
            ReadDatabase();
        }

       

        private void Opendatabase()
        {
            try
            {
               sqlConnection = new MySqlConnection(connectionString);
               sqlConnection.Open();
            }
            catch (Exception)
            {
                MessageBox.Show("Can't connect to the database");
            }
        }


        private void OpenCategories()
        {
            string sqlCategoriesOrdered = "SELECT DISTINCT kategória FROM    termékek ORDER BY kategória;";
            MySqlCommand sqlCommand = new MySqlCommand(sqlCategoriesOrdered,sqlConnection);
            MySqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

            cbKategoria.Items.Add(" - Nincs megadva - ");

            while (sqlDataReader.Read())
            {
                cbKategoria.Items.Add(sqlDataReader.GetString(0));
            }
            sqlDataReader.Close();
            cbKategoria.SelectedIndex = 0;
        }
        private void OpenProviders()
        {
            string sqlProvidersOrdered = "SELECT DISTINCT gyártó FROM termékek ORDER BY gyártó;";
            MySqlCommand sqlCommand = new MySqlCommand(sqlProvidersOrdered, sqlConnection);
            MySqlDataReader sqlDataReader = sqlCommand.ExecuteReader();

            cbGyarto.Items.Add(" - Nincs megadva - ");

            while (sqlDataReader.Read())
            {
                cbGyarto.Items.Add(sqlDataReader.GetString(0));
            }
            sqlDataReader.Close();
            cbGyarto.SelectedIndex = 0;
        }
        private void ReadDatabase()
        {
            string connectString = "SELECT * FROM termékek";
            MySqlCommand sqlCommand = new MySqlCommand(connectString, sqlConnection);
            MySqlDataReader sqlDatareader = sqlCommand.ExecuteReader();
            while (sqlDatareader.Read())
            {
                termek termekek = new termek(
                    sqlDatareader.GetString(1),
                    sqlDatareader.GetString(2),
                    sqlDatareader.GetString(3),
                    sqlDatareader.GetInt32(4),
                    sqlDatareader.GetInt32(5)
                    );
                Termekek.Add(termekek);
            }
            sqlDatareader.Close();
            dgTermekek.ItemsSource = Termekek;
        }



        private string UpdateList()
        {
            bool condition = false;
            string UpdatedList = "SELECT * FROM termékek ";

            if (cbGyarto.SelectedIndex > 0 || cbKategoria.SelectedIndex > 0 || txtTermek.Text != "")
            {
                UpdatedList += "WHERE ";
            }
            if (cbGyarto.SelectedIndex > 0)
            {
                UpdatedList += $"gyártó='{cbGyarto.SelectedItem}'";
                condition = true;
            }
            if (cbKategoria.SelectedIndex > 0)
            {
                if (condition)
                {
                    UpdatedList += " AND ";
                }
                UpdatedList += $"kategória='{cbKategoria.SelectedItem}'";
                condition = true;
            }
            if (txtTermek.Text != "")
            {
                if (condition)
                {
                    UpdatedList += " AND ";
                }
                UpdatedList += $"név LIKE '%{txtTermek.Text}%'";
            }
            return UpdatedList;
        }

        private void btnSzukit_Click(object sender, RoutedEventArgs e)
        {
            Termekek.Clear();
            string sqlUpdatedList = UpdateList();
            MySqlCommand sqlCommand = new MySqlCommand(sqlUpdatedList, sqlConnection);
            MySqlDataReader reader = sqlCommand.ExecuteReader();

            while (reader.Read())
            {
                termek newList = new termek
                    (
                    reader.GetString(1),
                    reader.GetString(2),
                    reader.GetString(3),
                    reader.GetInt32(4),
                    reader.GetInt32(5)
                    );
                Termekek.Add(newList);
            }
            reader.Close();
            dgTermekek.Items.Refresh();
        }
        public bool IsClosed { get; private set; }
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            IsClosed = true;
            if (IsClosed)
            {
                sqlConnection.Close();
                sqlConnection.Dispose();
            }
        }
    }
}
